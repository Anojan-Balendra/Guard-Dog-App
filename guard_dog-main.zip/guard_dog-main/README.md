# guard_dog
A rep for cp317 Guard Dog Project

The idea of this project was influenced by recent events at Western University campus of the alleged drugging and assault of first-year students on a university residence. 
The general functionality of the application allows a user to login or register to get access to a map screen showing the locations of reported incidents. Using the navigation bar, the user can then see alerts, access an EMS page, make a report or logout. 

Current UI


![alt text](https://github.com/sdiabillz/guard_dog/blob/main/diagrams%20and%20report/Login.JPG?raw=true)
![alt text](https://github.com/sdiabillz/guard_dog/blob/main/diagrams%20and%20report/Map.JPG?raw=true)
![alt text](https://github.com/sdiabillz/guard_dog/blob/main/diagrams%20and%20report/Report.JPG?raw=true)
![alt text](https://github.com/sdiabillz/guard_dog/blob/main/diagrams%20and%20report/Alerts.JPG?raw=true)
