package com.example.guard_dog_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
