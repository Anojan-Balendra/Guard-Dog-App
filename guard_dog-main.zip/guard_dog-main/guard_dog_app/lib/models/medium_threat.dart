import 'incident.dart';

class medium_threat extends Incident{
  // @override
  // Future<Position> _getGeoLocationPosition() {
  //   return super._getGeoLocationPosition();
  // }

  // @override
  // void printall() {
  //   super.printall();
  // }
  //
  // @override
  // Future<void> addincident() {
  //   return super.addincident();
  // }

  String help_numbers(){

    return """Please call this number if the situation is not an emergency:
    
Non-Emergency Number: 519-570-9777
    """;

  }

}
