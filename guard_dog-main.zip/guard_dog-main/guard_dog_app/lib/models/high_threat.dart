
import 'incident.dart';

class high_threat extends Incident{
  //
  // @override
  // Future<Position> _getGeoLocationPosition() {
  //   return super._getGeoLocationPosition();
  // }


  // @override
  // void printall() {
  //   super.printall();
  // }

  // @override
  // Future<void> addincident() {
  //   return super.addincident();
  // }

  void call911(){

  }

}

