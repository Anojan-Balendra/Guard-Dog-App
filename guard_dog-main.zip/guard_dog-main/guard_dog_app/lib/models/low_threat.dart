
import 'incident.dart';

class low_threat extends Incident{
  // @override
  // Future<Position> _getGeoLocationPosition() {
  //   return super._getGeoLocationPosition();
  // }

  // @override
  // Future<void> addincident() {
  //   return super.addincident();
  // }
  //
  // @override
  // void printall() {
  //   super.printall();
  // }

  String help_numbers(){

    return """Please note that even low level incidents are taken seriously, thank you for using Guard Dog.
    """;

  }

}